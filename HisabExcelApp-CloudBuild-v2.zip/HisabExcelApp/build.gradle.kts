plugins {
    // Conservative versions chosen for on-device Android IDE builds.
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
