# Build Hisab Excel APK directly on an Android phone

## Recommended: AndroidIDE

AndroidIDE can open and build real Gradle Android projects directly on Android devices. It supports JDK 11/17 and Android SDK management. Note: the original AndroidIDE project is archived/unmaintained, so install it only from a trusted source such as its official GitHub releases or F-Droid.

### 1. Install AndroidIDE
Use the official AndroidIDE GitHub/F-Droid source.

### 2. Install build tools
Open AndroidIDE and install its recommended build tools. Make sure JDK 17 and Android SDK Platform 34 are available.

### 3. Extract this ZIP
Extract `HisabExcelApp-phone.zip` into a normal folder such as `Internal storage/AndroidIDE/Projects/HisabExcelApp`.

### 4. Open the project
AndroidIDE -> Open existing project -> select the `HisabExcelApp` folder (the folder containing `settings.gradle.kts`).

### 5. Let Gradle sync
Wait until the project synchronization finishes successfully. The first sync can take several minutes because Gradle/dependencies may need to be downloaded.

### 6. Build/install the APK
Tap the Run/Build action in AndroidIDE. For an APK only, use the terminal inside AndroidIDE and run:

```
gradle :app:assembleDebug
```

The APK will be:

`app/build/outputs/apk/debug/app-debug.apk`

You can tap the APK from AndroidIDE's file browser and install it. If Android asks, allow AndroidIDE to install unknown apps.

## If Gradle command is not found
Use AndroidIDE's normal Run/Build button after project sync. AndroidIDE manages the Gradle build environment for imported projects.

## App details
- Offline; no server, SQL, or .NET.
- Records are stored locally in SharedPreferences as JSON.
- Excel is generated as a real `.xlsx` file using the Android/JDK ZIP APIs; no Excel library is required.
- Android 10+ exports directly to the Downloads collection.
- The app has Add/Edit/Delete/Search and Excel Share.

## Important
The first build requires internet access to download Gradle and Maven dependencies. After the dependencies are cached, later builds are much faster.
