# Hisab Excel App

Android app for entering हिसाब records, saving them locally on the phone, and exporting them as an `.xlsx` Excel file.

## Important
This project does **not** use .NET or a database. Data is stored locally in Android SharedPreferences.

## Build APK from a phone using GitHub Actions
1. Upload this ZIP to a GitHub repository and extract its contents into the repository root. Do not leave the ZIP as the only project file.
2. Make sure `.github/workflows/build-apk.yml` exists at the repository root.
3. Open GitHub → **Actions** → **Build Hisab Excel APK**.
4. Tap **Run workflow** and choose `main`.
5. Wait for the green **Success** result.
6. Open the successful run and download the artifact named **HisabExcel-debug-apk**.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Project root
The repository root must contain:
- `settings.gradle.kts`
- `build.gradle.kts`
- `app/`
- `.github/workflows/build-apk.yml`

## AndroidIDE
The project includes Gradle build files, but the cloud workflow is the recommended method when building only from a phone.
