# Build the APK from your phone using GitHub Actions (no PC)

If AndroidIDE is difficult to install, this project includes a GitHub Actions workflow that builds the APK on GitHub's servers.

## Steps on your Android phone
1. Open GitHub in Chrome and sign in/create an account.
2. Create a new **private repository**, for example `HisabExcelApp`.
3. Open the repository and use **Add file -> Upload files**.
4. GitHub's web uploader is easiest if you upload the project files/folders individually. Keep the folder structure exactly as in this ZIP and upload the `.github`, `app`, `gradle`, and root files.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build Hisab Excel APK**.
7. Tap **Run workflow** if it has not started automatically.
8. Wait for the workflow to finish with a green check.
9. Open the completed workflow run. In **Artifacts**, download `HisabExcel-debug-apk`.
10. Extract the downloaded artifact and install `app-debug.apk` on your phone.

This method uses GitHub's build machine, so your phone does not need Android Studio, Android SDK, or Gradle installed.
