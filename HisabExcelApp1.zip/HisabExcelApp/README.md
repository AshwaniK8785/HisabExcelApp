# Hisab Excel - Android Studio Project

A small offline Android app for handwritten-style hisab/ledger records.

## Features
- No SQL database
- No .NET/server
- Data stored locally on the phone as JSON in SharedPreferences
- Name, previous balance, principal (मूल), interest (ब्याज), paid (जमा), remarks
- Total = Principal + Interest
- Remaining = Previous Balance + Total - Paid
- Add, edit, delete, search records
- Generate a real `.xlsx` Excel file without an Excel library/server
- Save Excel to the Downloads folder on Android 10+
- Share generated Excel

## Open/build
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Select an Android emulator or USB-connected phone.
4. Run the `app` configuration.

Recommended: Android Studio with JDK 17 and Android SDK 35.

## Important
The handwritten image is used as the design reference. The app intentionally keeps the fields simple. If you want the exact names/rows/calculation rules from the notebook, those can be adjusted in `MainActivity.kt` and the layout.
