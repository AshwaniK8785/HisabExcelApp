package com.example.hisabexcel

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class HisabRecord(
    val id: Long,
    var name: String,
    var previous: Double,
    var principal: Double,
    var interest: Double,
    var paid: Double,
    var remarks: String,
    var date: String
) {
    val total: Double get() = principal + interest
    val remaining: Double get() = previous + total - paid
}

class MainActivity : AppCompatActivity() {
    private lateinit var etName: EditText
    private lateinit var etPrevious: EditText
    private lateinit var etPrincipal: EditText
    private lateinit var etInterest: EditText
    private lateinit var etTotal: EditText
    private lateinit var etPaid: EditText
    private lateinit var etRemaining: EditText
    private lateinit var etRemarks: EditText
    private lateinit var etSearch: EditText
    private lateinit var recordsContainer: LinearLayout
    private lateinit var tvSummary: TextView
    private val records = mutableListOf<HisabRecord>()
    private var editingId: Long? = null
    private var lastExportUri: Uri? = null
    private val prefs by lazy { getSharedPreferences("hisab_data", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews(); loadRecords(); setupCalculations(); setupButtons(); renderRecords()
    }

    private fun bindViews() {
        etName = findViewById(R.id.etName); etPrevious = findViewById(R.id.etPrevious)
        etPrincipal = findViewById(R.id.etPrincipal); etInterest = findViewById(R.id.etInterest)
        etTotal = findViewById(R.id.etTotal); etPaid = findViewById(R.id.etPaid)
        etRemaining = findViewById(R.id.etRemaining); etRemarks = findViewById(R.id.etRemarks)
        etSearch = findViewById(R.id.etSearch); recordsContainer = findViewById(R.id.recordsContainer)
        tvSummary = findViewById(R.id.tvSummary)
    }

    private fun setupCalculations() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateCalculatedFields() }
            override fun afterTextChanged(s: Editable?) {}
        }
        etPrevious.addTextChangedListener(watcher); etPrincipal.addTextChangedListener(watcher)
        etInterest.addTextChangedListener(watcher); etPaid.addTextChangedListener(watcher)
    }

    private fun updateCalculatedFields() {
        val total = num(etPrincipal.text.toString()) + num(etInterest.text.toString())
        val remaining = num(etPrevious.text.toString()) + total - num(etPaid.text.toString())
        etTotal.setText(money(total)); etRemaining.setText(money(remaining))
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveRecord() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearForm() }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportExcel(false) }
        findViewById<Button>(R.id.btnShare).setOnClickListener {
            if (lastExportUri == null) exportExcel(true) else shareExcel(lastExportUri!!)
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderRecords() }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun saveRecord() {
        val name = etName.text.toString().trim()
        if (name.isEmpty()) { etName.error = "Name required"; etName.requestFocus(); return }
        val record = HisabRecord(
            editingId ?: System.currentTimeMillis(), name, num(etPrevious.text.toString()),
            num(etPrincipal.text.toString()), num(etInterest.text.toString()), num(etPaid.text.toString()),
            etRemarks.text.toString().trim(), SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date())
        )
        val index = records.indexOfFirst { it.id == record.id }
        if (index >= 0) records[index] = record else records.add(record)
        persistRecords(); Toast.makeText(this, if (index >= 0) "Record updated" else "Record saved", Toast.LENGTH_SHORT).show()
        clearForm(); renderRecords()
    }

    private fun clearForm() {
        editingId = null
        etName.text.clear(); etPrevious.text.clear(); etPrincipal.text.clear(); etInterest.text.clear(); etPaid.text.clear(); etRemarks.text.clear()
        etTotal.setText("0.00"); etRemaining.setText("0.00")
        findViewById<Button>(R.id.btnSave).text = "SAVE"
    }

    private fun editRecord(r: HisabRecord) {
        editingId = r.id; etName.setText(r.name); etPrevious.setText(money(r.previous)); etPrincipal.setText(money(r.principal))
        etInterest.setText(money(r.interest)); etPaid.setText(money(r.paid)); etRemarks.setText(r.remarks); updateCalculatedFields()
        findViewById<Button>(R.id.btnSave).text = "UPDATE"; etName.requestFocus()
    }

    private fun deleteRecord(r: HisabRecord) {
        AlertDialog.Builder(this).setTitle("Delete record?").setMessage("Delete ${r.name} permanently from this phone?")
            .setNegativeButton("CANCEL", null).setPositiveButton("DELETE") { _, _ ->
                records.removeAll { it.id == r.id }; persistRecords(); renderRecords(); Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun renderRecords() {
        recordsContainer.removeAllViews()
        val q = etSearch.text.toString().trim().lowercase(Locale.getDefault())
        val filtered = records.filter { it.name.lowercase(Locale.getDefault()).contains(q) }
        var previous = 0.0; var principal = 0.0; var interest = 0.0; var paid = 0.0; var remaining = 0.0
        filtered.forEach { r ->
            previous += r.previous; principal += r.principal; interest += r.interest; paid += r.paid; remaining += r.remaining
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); setBackgroundResource(android.R.drawable.dialog_holo_light_frame) }
            card.addView(TextView(this).apply { text = "${r.name}  •  ${r.date}"; textSize = 17f; setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply {
                text = "पिछला: ${money(r.previous)}   मूल: ${money(r.principal)}   ब्याज: ${money(r.interest)}\n" +
                    "कुल: ${money(r.total)}   जमा: ${money(r.paid)}   बाकी: ${money(r.remaining)}" + if (r.remarks.isNotBlank()) "\nटिप्पणी: ${r.remarks}" else ""
                textSize = 14f; setPadding(0, 6, 0, 8)
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val edit = Button(this).apply { text = "EDIT"; setOnClickListener { editRecord(r) } }
            val del = Button(this).apply { text = "DELETE"; setOnClickListener { deleteRecord(r) } }
            actions.addView(edit, LinearLayout.LayoutParams(0, -2, 1f)); actions.addView(del, LinearLayout.LayoutParams(0, -2, 1f)); card.addView(actions)
            recordsContainer.addView(card); recordsContainer.addView(Space(this), LinearLayout.LayoutParams(1, 10))
        }
        tvSummary.text = "Records: ${records.size}  |  Filtered: ${filtered.size}\nPrevious: ${money(previous)}  |  Principal: ${money(principal)}  |  Interest: ${money(interest)}\nPaid: ${money(paid)}  |  Remaining: ${money(remaining)}"
    }

    private fun persistRecords() {
        val a = JSONArray(); records.forEach { r -> a.put(JSONObject().apply { put("id", r.id); put("name", r.name); put("previous", r.previous); put("principal", r.principal); put("interest", r.interest); put("paid", r.paid); put("remarks", r.remarks); put("date", r.date) }) }
        prefs.edit().putString("records", a.toString()).apply()
    }

    private fun loadRecords() {
        val raw = prefs.getString("records", null) ?: return
        try { val a = JSONArray(raw); for (i in 0 until a.length()) { val o = a.getJSONObject(i); records.add(HisabRecord(o.optLong("id"), o.optString("name"), o.optDouble("previous"), o.optDouble("principal"), o.optDouble("interest"), o.optDouble("paid"), o.optString("remarks"), o.optString("date"))) } }
        catch (_: Exception) { Toast.makeText(this, "Saved data could not be read", Toast.LENGTH_LONG).show() }
    }

    private fun exportExcel(andShare: Boolean) {
        if (records.isEmpty()) { Toast.makeText(this, "No records to export", Toast.LENGTH_SHORT).show(); return }
        try {
            val fileName = "Hisab_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.xlsx"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Could not create Downloads file")
                contentResolver.openOutputStream(uri)?.use { createXlsx(it) } ?: error("Could not open Downloads file")
                lastExportUri = uri; Toast.makeText(this, "Excel saved in Downloads/$fileName", Toast.LENGTH_LONG).show(); if (andShare) shareExcel(uri)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); if (!dir.exists()) dir.mkdirs()
                val file = File(dir, fileName); FileOutputStream(file).use { createXlsx(it) }
                val shareCopy = File(cacheDir, fileName); file.copyTo(shareCopy, overwrite = true)
                lastExportUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", shareCopy)
                Toast.makeText(this, "Excel saved in Downloads/$fileName", Toast.LENGTH_LONG).show()
                if (andShare) shareExcel(lastExportUri!!)
            }
        } catch (e: Exception) { Toast.makeText(this, "Excel export failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun shareExcel(uri: Uri) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(i, "Share Excel"))
    }

    private fun createXlsx(out: OutputStream) {
        ZipOutputStream(out).use { z ->
            add(z, "[Content_Types].xml", contentTypes())
            add(z, "_rels/.rels", rootRels())
            add(z, "xl/workbook.xml", workbook())
            add(z, "xl/_rels/workbook.xml.rels", workbookRels())
            add(z, "xl/styles.xml", styles())
            add(z, "xl/worksheets/sheet1.xml", sheet())
        }
    }
    private fun add(z: ZipOutputStream, name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }

    private fun contentTypes() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>"""
    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    private fun workbook() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Hisab" sheetId="1" r:id="rId1"/></sheets></workbook>"""
    private fun workbookRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    private fun styles() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="0.00"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" applyFont="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""

    private fun sheet(): String {
        val s = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        val headers = listOf("क्रम", "नाम", "पिछला बकाया", "मूल", "ब्याज", "कुल", "जमा/भुगतान", "बाकी", "तारीख", "टिप्पणी")
        s.append("<row r=\"1\">"); headers.forEachIndexed { i, h -> s.append(inlineCell(col(i + 1) + "1", h, 1)) }; s.append("</row>")
        records.forEachIndexed { i, r ->
            val row = i + 2; s.append("<row r=\"$row\">")
            s.append(numCell("A$row", (i + 1).toString())); s.append(inlineCell("B$row", r.name)); s.append(numCell("C$row", r.previous.toString())); s.append(numCell("D$row", r.principal.toString())); s.append(numCell("E$row", r.interest.toString())); s.append(numCell("F$row", r.total.toString())); s.append(numCell("G$row", r.paid.toString())); s.append(numCell("H$row", r.remaining.toString())); s.append(inlineCell("I$row", r.date)); s.append(inlineCell("J$row", r.remarks)); s.append("</row>")
        }
        s.append("</sheetData><cols>")
        listOf(8,24,16,14,14,14,16,14,20,30).forEachIndexed { i, w -> s.append("<col min=\"${i+1}\" max=\"${i+1}\" width=\"$w\" customWidth=\"1\"/>") }
        s.append("</cols></worksheet>"); return s.toString()
    }
    private fun inlineCell(ref: String, value: String, style: Int = 0) = "<c r=\"$ref\" t=\"inlineStr\" s=\"$style\"><is><t>${xml(value)}</t></is></c>"
    private fun numCell(ref: String, value: String) = "<c r=\"$ref\" s=\"2\"><v>$value</v></c>"
    private fun col(n: Int): String { var x=n; val s=StringBuilder(); while(x>0){ val r=(x-1)%26; s.append(('A'.code+r).toChar()); x=(x-1)/26 }; return s.reverse().toString() }
    private fun xml(v: String) = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    private fun num(v: String) = v.trim().toDoubleOrNull() ?: 0.0
    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
}
